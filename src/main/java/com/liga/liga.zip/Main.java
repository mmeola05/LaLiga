package com.liga;

import com.liga.controller.UserMenuController;

public class Main {
    public static void main(String[] args) {
        new UserMenuController().iniciarApp();
    }
}
