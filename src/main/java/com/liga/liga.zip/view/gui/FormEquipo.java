package com.liga.view.gui;

public class FormEquipo {
}
