package com.liga.model;

import java.util.List;

public class Mercado {
    private List<JugadorMercado> jugadoresEnMercado;
}
