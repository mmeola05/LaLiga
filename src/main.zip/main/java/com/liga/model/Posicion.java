package com.liga.model;

public enum Posicion {
    PORTERO,
    DEFENSA,
    MEDIO,
    DELANTERO
}
