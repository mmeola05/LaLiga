package com.liga.model;

public class Jornada {
}
