package com.liga.model;

public enum TipoUsuario {
    ADMIN,
    ESTANDAR
}