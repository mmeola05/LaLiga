package com.liga.repository;

public class RepositoryFactory {
}
